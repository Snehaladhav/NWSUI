// import logo from './logo.svg';
// import './App.css';
import React from 'react';
// import Info from './Components/Info';
// import HeroImg2 from './Components/HeroImg2';
// import Navbar from './Components/Navbar';
import Corousel from './Components/Corousel';
// import Slider from './Components/Slider';
// import CoroTrupti from "./Components/CoroTrupti";
import Home from "./Components/Home";





function App() {
  return (
    <div className="App">
     {/* <Navbar/> */}
   {/* <Corousel/> */}
   {/* <Slider/> */}
   {/* <CoroTrupti/> */}
   {/* <HeroImg2/> */}
   {/* <Info/> */}
<Home/>
   
    </div>

  );
}

export default App;
