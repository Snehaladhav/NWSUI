import React from "react";
import Carousel from "react-bootstrap/Carousel";
import Grid from "@mui/material/Grid";
import Box from "@mui/material/Box";
import {
  Stack,
  Typography,
  Container,
  ImageList,
  ImageListItem,
} from "@mui/material";
// import Carousel from "react-bootstrap/Carousel";
import 'bootstrap/dist/css/bootstrap.css';

import Home_Image from "../../Assets/Images/clean2.jpg";
import HomeImage from "../../Assets/Images/Courasal1.jpg";
import HomeImag from "../../Assets/Images/Courasal2.jpg";
import HomeImag1 from "../../Assets/Images/Courasal3.jpg";
import HomeImag2 from "../../Assets/Images/cl8.jpg";
;


export default function Landing() {
    const HomeImage=[ HomeImag,HomeImag1, HomeImag2,Home_Image,HomeImag]

  

  return (
    <>

      <div

        style={{ display: 'block', width: "100%", height: "600" }}

      >

        <Carousel className="carousel-inner">
          <Carousel.Item interval={1500}  >
            
            <div className="container1">
            <img className="d-block w-100" src="https://www.babahousekeeping.com/img/slider/h2.jpg" alt="First slide" style={{ width: "100%" }} />
      </div>

      <div className="text">
        <h5>Genei Facility Management </h5>

        <p>
          `Genei’ is a professional Housekeeping & Specialized Cleaning company
          that understands the importance of working and living in clean
          Hygienic environment. We take short and long term housekeeping cum
          cleaning contracts for homes and Big, small, mid-sizeoffices,
          maintaining gardens; and also providing entry level manpower resource.{" "}
        </p>
        <button className="info">Book Now</button>
      </div>
             

          </Carousel.Item>
    

        </Carousel>
        <div >
        {
            HomeImage.map((ele) =>{
                return(
                    <div className="demo" >
                    <img style={{width:"100%"}} className="HomeImage"
                    src={ele}alt="HomeImag1">

                    </img>

                    </div>
                );
            })
        }

        </div>

      </div>


    </>
  );
}