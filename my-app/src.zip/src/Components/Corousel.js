import React from "react";
import "../App.css";
import officeClean1 from "../asset/officeClean1.jpg";

const Corousel = () => {
  return (
    <div style={{ fontFamily: "poppins" }}>
      <div className="container1">
        <img className="bgImage" src={officeClean1} alt="officeClean1"/>
      </div>

      <div className="text">
        <h5>Sparkle With Us </h5>

        <p>
          Sparkle is a professional Housekeeping & Specialized Cleaning company
          that understands the importance of working and living in clean
          Hygienic environment. We take short and long term housekeeping cum
          cleaning contracts for homes and Big, small, mid-sizeoffices,
          maintaining gardens; and also providing entry level manpower resource.{" "}
        </p>
        <button className="info">Book Now</button>
      </div>
    </div>
  );
};

export default Corousel;


