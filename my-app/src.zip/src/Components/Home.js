// import React from "react";
// import "../App.css";
// import Carousel from "react-bootstrap/Carousel";
// import 'bootstrap/dist/css/bootstrap.css';

// const slides = [
//   {
//     image: './Images/tat1.jpg',
//     text: {
//       title: "Sparkle With Us !",
//       description:
//         "`Genei’ is a professional Housekeeping & Specialized Cleaning company that understands the importance of working and living in a clean Hygienic environment.",
//     },
//   },
//   {
//     image: './Images/tat10.jpg',
//     text: {
//       title: " Sparkle With Us !",
//       description: "We Are Best Solution For Your House Cleaning Services We Can Work Hard For Perfect Clean Your Own House Today",
//     },

//   },
//   {
//     image: './Images/tat12.jpg',
//     text: {
//       title: "TRUSTED | SIMPLE | AFFORDABLE",
//       description: "We take short and long term housekeeping cum cleaning contracts for homes and Big, small, mid-size offices, maintaining gardens; and also providing entry-level manpower resource.",
//     },

//   },
//   {
//     image: './Images/tat14.jpg',
//     text: {
//       title: "Clean House, Clean Mind & Happy Work Today",
//       description: "Professional Cleaning Services To Keep Your Home Clean And Ready For Everything ",
//     },

//   },
//   {
//     image: './Images/tat3.jpg',
//     text: {
//       title: "We Provide Our Best Cleaning Services",
//       description: "Our Services include housekeeping services, deep cleaning,residential apartment cleaning, corporate office cleaning,bathroom cleaning,intensive cleaning and mattress cleaning for both residential and commercial clients.",
//     },

//   },

// ];

// export default function Landing() {
//   return (
//     <>
//       <div style={{ display: 'block', width: "100%", height: "600px" }} className="crsl">
//         <Carousel className="carousel-inner transition1" >
//           {slides.map((slide, index) => (
//             <Carousel.Item key={index} interval={4000}>
//               <div style={{height:"600px"}}>
//               <img className="d-block w-100"  src={slide.image} alt={`Slide ${index + 1}`} style={{ width: "100%",height:"100%",opacity:"0.5"}} />
//               <div  className="cours">

//               </div>
//               </div>
//               <div className="text">
//                 <h5>{slide.text.title}</h5>
//                 <p>{slide.text.description}</p>
//                 <button className="info">Book Now</button>
//               </div>
//             </Carousel.Item>
//           ))}
//         </Carousel>
//       </div>
//     </>
//   );
//           }
import React from "react";
import "../App.css";
import Carousel from "react-bootstrap/Carousel";
import "bootstrap/dist/css/bootstrap.css";

const slides = [
  {
    image: "./Images/tat1.jpg",
  },

  {
    image: "./Images/tat10.jpg",
  },
  {
    image: "./Images/tat12.jpg",
  },
  {
    image: "./Images/tat14.jpg",
  },
  {
    image: "./Images/tat3.jpg",
  },
];

export default function Landing() {
  return (
    <div >
      <div
        style={{ display: "block", width: "100%", height: "50%" }}
        className="crsl"
      >
        <Carousel className="carousel-inner transition1">
          {slides.map((slide, index) => (
            <Carousel.Item key={index} interval={4000}>
              <div style={{ height: "600px" }}>
                <img
                  className="d-block w-100"
                  src={slide.image}
                  alt={`Slide ${index + 1}`}
                  style={{ width: "100%", height: "100%", opacity: "0.5" }}
                />
                <div className="cours"></div>
              </div>
            </Carousel.Item>
          ))}
        </Carousel>
      </div>
    </div>
  );
}
